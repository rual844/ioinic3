import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  // private ibnUl: HTMLElement[];

  PlanList: planItem[];
  constructor(public navCtrl: NavController) {
    this.PlanList = [
      {
        id: 1,
        imgUrl: '../assets/imgs/ionic.jpg',
        title: 'Ionic Video',
        subTitle: '学习'
      },
      {
        id: 2,
        imgUrl: '../assets/imgs/sports.jpg',
        title: 'Sport',
        subTitle: '健身'
      },
      {
        id: 3,
        imgUrl: '../assets/imgs/ai.jpg',
        title: 'Artificial Intelligence',
        subTitle: 'AI'
      }
    ];

  }

  actionDetail(selectItem) {
    this.navCtrl.push('EditerPage', {planItem: selectItem});
    // this.ibnUl = this.element.nativeElement.querySelectorAll('li.ibn-li');
    // for (let i = 0; i < this.ibnUl.length; i++) {
    //   if (i%2 === 1) {
    //     this.ibnUl[i].style.color = 'red';
    //     this.ibnUl[i].style.marginLeft = '20px';
    //   }

    // }
  }

}

class planItem {
  id: number;
  imgUrl: string;
  title: string;
  subTitle: string;
}