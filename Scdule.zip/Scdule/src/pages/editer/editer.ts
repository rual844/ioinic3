import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { DetailComponent } from "../../components/detail/detail";

/**
 * Generated class for the EditerPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-editer',
  templateUrl: 'editer.html',
})
export class EditerPage {

  planObjA: detailObj[];
  planObjB: detailObj[];
  planObjC: detailObj[];
  planObj: any;
  planTitle: string;

  constructor(public navCtrl: NavController, public navParams: NavParams,
     public modalCtrl: ModalController) {
    let planItem = navParams.get('planItem');
    this.planTitle = planItem.title;
    this.getPlanInfo();

    if (planItem.id === 1) {
      this.planObj = this.planObjA;
    } else if (planItem.id === 2) {
      this.planObj = this.planObjB;
    } else if (planItem.id === 3) {
      this.planObj = this.planObjC;
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditerPage');
  }
  
  goToEditPage() {
    let editModal = this.modalCtrl.create(DetailComponent, {planTitle: this.planTitle,
       status: this.planObj[0].value,
        endLine: this.planObj[1].value});
    editModal.present();
    // this.navCtrl.push(DetailComponent);
  }

  private getPlanInfo() {
    this.planObjA = [
      {
        icon: 'sad',
        title: 'Status',
        color: 'danger',
        value: 'unfinished'
      },
      {
        icon: 'alarm',
        title: 'End Time',
        color: 'danger',
        value: '2018-08-07'
      }
    ];
    this.planObjB = [
      {
        icon: 'happy',
        title: 'Status',
        color: 'primary',
        value: 'finished'
      },
      {
        icon: 'alarm',
        title: 'End Time',
        color: 'primary',
        value: '2018-08-10'
      }
    ];
    this.planObjC = [
      {
        icon: 'bicycle',
        title: 'Status',
        color: 'secondary',
        value: 'ongoing'
      },
      {
        icon: 'alarm',
        title: 'End Time',
        color: 'secondary',
        value: '2018-08-07'
      }
    ];
  }

}

class detailObj {
  icon: string;
  title: string;
  color: string
  value: string;
};